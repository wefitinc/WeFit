Rails.application.config.middleware.use OmniAuth::Builder do
	provider :facebook, "2383595921758644", "a1d8ccae87640ca34cb2e541c02d03e8"
end
