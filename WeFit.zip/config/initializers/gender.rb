require 'acts_as_gendered'
ActiveRecord::Base.send(:include, ActsAsGendered)