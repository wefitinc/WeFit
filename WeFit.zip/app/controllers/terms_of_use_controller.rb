class TermsOfUseController < ApplicationController
  def index
  end
end
