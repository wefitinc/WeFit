class PrivacyPolicyController < ApplicationController
  def index
  end
end
