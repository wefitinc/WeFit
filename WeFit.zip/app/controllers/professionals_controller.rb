class ProfessionalsController < ApplicationController
  def index
  end
end
