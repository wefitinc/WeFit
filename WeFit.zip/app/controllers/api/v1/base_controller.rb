class Api::V1::BaseController < ActionController::API
end