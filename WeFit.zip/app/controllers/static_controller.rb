class StaticController < ApplicationController
	def about
	end
	def terms_of_use
	end
	def privacy_policy
	end
	def ad_manager
	end
	def professionals
	end
	def contact
	end
end
