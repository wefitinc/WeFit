class StaticController < ApplicationController
	def about
	end
	def terms_of_use
	end
	def privacy_policy
	end
	def advertising
	end
	def professionals
	end
	def community_guidelines
	end
	def cookie_policy
	end
	def advertising_policy
	end
	def branding_assets	
	end
	def account_help
		
	end
	def what_is_we_fit
	end
end
