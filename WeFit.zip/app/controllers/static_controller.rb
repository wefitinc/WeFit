class StaticController < ApplicationController
	def about
	end
	def terms_of_use
	end
	def privacy_policy
	end
	def advertising
	end
	def professionals
	end
	def welcome
	end
	def signup
	end
end
