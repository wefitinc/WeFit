class ApplicationMailer < ActionMailer::Base
  default from: 'WefitTest@gmail.com'
  layout 'mailer'
end
