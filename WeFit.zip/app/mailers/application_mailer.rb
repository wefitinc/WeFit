class ApplicationMailer < ActionMailer::Base
  default from: 'noreply@wefit.us'
  layout 'mailer'
end
