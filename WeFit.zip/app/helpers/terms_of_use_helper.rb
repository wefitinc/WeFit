module TermsOfUseHelper
end
