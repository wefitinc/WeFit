module StaticHelper
end
