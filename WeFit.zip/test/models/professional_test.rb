require 'test_helper'

class ProfessionalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
